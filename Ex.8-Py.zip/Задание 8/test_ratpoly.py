import unittest
from ratnum import RatNum
from ratpoly import RatPoly


def poly(*coeffs):
    return RatPoly.from_coefficients([RatNum(c) for c in coeffs])


class TestConstruction(unittest.TestCase):
    def test_zero_polynomial(self):
        z = RatPoly()
        self.assertEqual(str(z), "0")
        self.assertFalse(z.is_nan())

    def test_single_term(self):
        p = RatPoly(RatNum(3), 2)
        self.assertEqual(str(p), "3*x^2")

    def test_zero_coeff_collapses_to_zero_poly(self):
        p = RatPoly(RatNum(0), 5)
        self.assertEqual(p, RatPoly())

    def test_nan_coeff_makes_nan_poly(self):
        p = RatPoly(RatNum.NAN, 3)
        self.assertTrue(p.is_nan())

    def test_from_coefficients(self):
        p = poly(0, 0, -1, 0, 0)  
        p2 = RatPoly.from_coefficients(
            [RatNum(1, 7), RatNum(0), RatNum(-1), RatNum(0), RatNum(3, 2)]
        )
        self.assertEqual(str(p2), "3/2*x^4 - x^2 + 1/7")

    def test_negative_expt_rejected(self):
        with self.assertRaises(ValueError):
            RatPoly(RatNum(1), -1)


class TestDegree(unittest.TestCase):
    def test_ordinary(self):
        self.assertEqual(poly(1, 2, 3).degree(), 2)

    def test_leading_zero_terms_ignored(self):
        p = RatPoly.from_coefficients([RatNum(1), RatNum(2), RatNum(0)])
        self.assertEqual(p.degree(), 1)

    def test_zero_poly_throws(self):
        with self.assertRaises(ValueError):
            RatPoly().degree()

    def test_nan_throws(self):
        with self.assertRaises(ValueError):
            RatPoly.NAN.degree()


class TestGetCoeff(unittest.TestCase):
    def test_present_term(self):
        p = poly(1, 2, 3)
        self.assertEqual(p.get_coeff(1), RatNum(2))

    def test_absent_term_is_zero(self):
        p = poly(1, 0, 3)
        self.assertEqual(p.get_coeff(1), RatNum(0))
        self.assertEqual(p.get_coeff(99), RatNum(0))

    def test_nan_poly_returns_nan_everywhere(self):
        self.assertTrue(RatPoly.NAN.get_coeff(0).is_nan())
        self.assertTrue(RatPoly.NAN.get_coeff(100).is_nan())


class TestIsNan(unittest.TestCase):
    def test_true_case(self):
        self.assertTrue(RatPoly.NAN.is_nan())

    def test_false_case(self):
        self.assertFalse(poly(1, 2).is_nan())


class TestScaleCoeff(unittest.TestCase):
    def test_ordinary(self):
        p = poly(1, 2, 3)
        scaled = p.scale_coeff(RatNum(2))
        self.assertEqual(scaled, poly(2, 4, 6))

    def test_scale_by_zero(self):
        p = poly(1, 2, 3)
        self.assertEqual(p.scale_coeff(RatNum(0)), RatPoly())

    def test_nan_propagates(self):
        self.assertTrue(poly(1, 2).scale_coeff(RatNum.NAN).is_nan())
        self.assertTrue(RatPoly.NAN.scale_coeff(RatNum(2)).is_nan())


class TestArithmetic(unittest.TestCase):
    def test_neg(self):
        self.assertEqual(-poly(1, -2, 3), poly(-1, 2, -3))

    def test_add(self):
        self.assertEqual(poly(1, 2) + poly(3, 4, 5), poly(4, 6, 5))

    def test_add_cancels_terms(self):
        self.assertEqual(poly(1, 2, 3) + poly(-1, -2, -3), RatPoly())

    def test_sub(self):
        self.assertEqual(poly(5, 5) - poly(1, 2), poly(4, 3))

    def test_mul(self):
        x_plus_1 = poly(1, 1)
        x_minus_1 = poly(-1, 1)
        self.assertEqual(x_plus_1 * x_minus_1, poly(-1, 0, 1))

    def test_mul_by_zero(self):
        self.assertEqual(poly(1, 2, 3) * RatPoly(), RatPoly())

    def test_div_exact(self):
        numerator = poly(-1, 0, 1)
        divisor = poly(1, 1)
        self.assertEqual(numerator / divisor, poly(-1, 1))

    def test_div_by_zero_poly_is_nan(self):
        self.assertTrue((poly(1, 2) / RatPoly()).is_nan())

    def test_nan_propagates_through_arithmetic(self):
        self.assertTrue((RatPoly.NAN + poly(1)).is_nan())
        self.assertTrue((poly(1) - RatPoly.NAN).is_nan())
        self.assertTrue((RatPoly.NAN * poly(1)).is_nan())
        self.assertTrue((poly(1) / RatPoly.NAN).is_nan())


class TestCalculus(unittest.TestCase):
    def test_differentiate(self):
        p = RatPoly.from_coefficients(
            [RatNum(1, 7), RatNum(0), RatNum(-1), RatNum(0), RatNum(3, 2)]
        )
        self.assertEqual(p.differentiate(), poly(0, -2, 0, 6))

    def test_differentiate_constant(self):
        self.assertEqual(poly(5).differentiate(), RatPoly())

    def test_differentiate_zero(self):
        self.assertEqual(RatPoly().differentiate(), RatPoly())

    def test_differentiate_nan(self):
        self.assertTrue(RatPoly.NAN.differentiate().is_nan())

    def test_anti_differentiate(self):
        p = poly(0, 1)
        ad = p.anti_differentiate(RatNum(5))
        self.assertEqual(ad, RatPoly.from_coefficients([RatNum(5), RatNum(0), RatNum(1, 2)]))

    def test_differentiate_then_antidifferentiate_roundtrip(self):
        p = RatPoly.from_coefficients(
            [RatNum(1, 7), RatNum(0), RatNum(-1), RatNum(0), RatNum(3, 2)]
        )
        d = p.differentiate()
        ad = d.anti_differentiate(RatNum(1, 7))
        self.assertEqual(ad, p)

    def test_anti_differentiate_nan(self):
        self.assertTrue(RatPoly.NAN.anti_differentiate(RatNum(0)).is_nan())
        self.assertTrue(poly(1).anti_differentiate(RatNum.NAN).is_nan())

    def test_integrate(self):
        p = poly(0, 1)
        self.assertEqual(p.integrate(RatNum(0), RatNum(1)), RatNum(1, 2))

    def test_integrate_nan(self):
        self.assertTrue(poly(1).integrate(RatNum.NAN, RatNum(1)).is_nan())
        self.assertTrue(RatPoly.NAN.integrate(RatNum(0), RatNum(1)).is_nan())


class TestEval(unittest.TestCase):
    def test_eval_exact(self):
        p = poly(1, 0, 1)
        self.assertEqual(p.eval(RatNum(3)), RatNum(10))

    def test_eval_rational_point(self):
        p = poly(0, 1)  # p(x) = x
        self.assertEqual(p.eval(RatNum(1, 2)), RatNum(1, 2))

    def test_eval_zero_poly(self):
        self.assertEqual(RatPoly().eval(RatNum(100)), RatNum(0))

    def test_eval_nan(self):
        self.assertTrue(poly(1, 2).eval(RatNum.NAN).is_nan())
        self.assertTrue(RatPoly.NAN.eval(RatNum(1)).is_nan())

    def test_value_of_float(self):
        p = poly(1, 0, 1)  # x^2 + 1
        self.assertAlmostEqual(p.value_of(3.0), 10.0)

    def test_value_of_nan(self):
        import math
        self.assertTrue(math.isnan(RatPoly.NAN.value_of(2.0)))


class TestStrHashEq(unittest.TestCase):
    def test_str_ordering_and_signs(self):
        p = RatPoly.from_coefficients(
            [RatNum(1, 7), RatNum(0), RatNum(-1), RatNum(0), RatNum(3, 2)]
        )
        self.assertEqual(str(p), "3/2*x^4 - x^2 + 1/7")

    def test_str_zero_and_nan(self):
        self.assertEqual(str(RatPoly()), "0")
        self.assertEqual(str(RatPoly.NAN), "NaN")

    def test_str_single_x(self):
        self.assertEqual(str(poly(0, 1)), "x")
        self.assertEqual(str(poly(0, -1)), "-x")

    def test_eq_value_based(self):
        p1 = poly(1, 2, 3)
        p2 = RatPoly.from_coefficients([RatNum(1), RatNum(2), RatNum(3)])
        self.assertEqual(p1, p2)

    def test_nan_equals_nan(self):
        self.assertEqual(RatPoly.NAN, RatPoly(RatNum.NAN, 5))

    def test_hash_consistent_with_eq(self):
        p1 = poly(1, 2, 3)
        p2 = RatPoly.from_coefficients([RatNum(1), RatNum(2), RatNum(3)])
        self.assertEqual(hash(p1), hash(p2))
        self.assertEqual(hash(RatPoly.NAN), hash(RatPoly(RatNum.NAN, 1)))

    def test_usable_in_sets(self):
        s = {poly(1, 2), poly(1, 2), poly(2, 1)}
        self.assertEqual(len(s), 2)


class TestImmutability(unittest.TestCase):
    def test_cannot_mutate(self):
        p = poly(1, 2)
        with self.assertRaises(AttributeError):
            p._terms = {}


if __name__ == "__main__":
    unittest.main()
