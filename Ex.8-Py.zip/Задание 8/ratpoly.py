from __future__ import annotations
from typing import Dict, Iterable, Tuple

from ratnum import RatNum


class RatPoly:
   
    __slots__ = ("_terms", "_is_nan")

    def __init__(self, coeff: RatNum = None, expt: int = 0):
       
        terms: Dict[int, RatNum] = {}
        is_nan = False

        if coeff is not None:
            if not isinstance(coeff, RatNum):
                raise TypeError("coeff must be a RatNum")
            if not isinstance(expt, int):
                raise TypeError("expt must be an int")
            if coeff.is_nan():
                is_nan = True
            elif coeff != RatNum.ZERO:
                if expt < 0:
                    raise ValueError("exponent must be non-negative")
                terms[expt] = coeff

        object.__setattr__(self, "_terms", terms)
        object.__setattr__(self, "_is_nan", is_nan)
        self._check_rep()

    def __setattr__(self, name, value):
        raise AttributeError("RatPoly is immutable")

    def _check_rep(self) -> None:
        """Internal helper: asserts the representation invariant holds."""
        assert isinstance(self._is_nan, bool)
        if self._is_nan:
            assert self._terms == {}
        else:
            for expt, coeff in self._terms.items():
                assert isinstance(expt, int) and expt >= 0
                assert isinstance(coeff, RatNum) and not coeff.is_nan()
                assert coeff != RatNum.ZERO

    @classmethod
    def from_coefficients(cls, coeffs: Iterable[RatNum]) -> "RatPoly":
        
        result = cls()
        for i, c in enumerate(coeffs):
            result = result + cls(c, i)
        return result

    @classmethod
    def _from_terms(cls, terms: Dict[int, RatNum]) -> "RatPoly":
       
        result = cls.__new__(cls)
        object.__setattr__(result, "_terms", dict(terms))
        object.__setattr__(result, "_is_nan", False)
        result._check_rep()
        return result



    def is_nan(self) -> bool:
        
        return self._is_nan

    def degree(self) -> int:
       
        if self._is_nan:
            raise ValueError("degree() is undefined for NaN")
        if not self._terms:
            raise ValueError("degree() is undefined for the zero polynomial")
        return max(self._terms.keys())

    def get_coeff(self, expt: int) -> RatNum:
       
        if self._is_nan:
            return RatNum.NAN
        return self._terms.get(expt, RatNum.ZERO)

   

    def scale_coeff(self, scalar: RatNum) -> "RatPoly":
     
        if self._is_nan or scalar.is_nan():
            return RatPoly.NAN
        if scalar == RatNum.ZERO:
            return RatPoly()
        new_terms = {expt: coeff * scalar for expt, coeff in self._terms.items()}
        return RatPoly._from_terms(new_terms)

    def __neg__(self) -> "RatPoly":
       
        if self._is_nan:
            return RatPoly.NAN
        return self.scale_coeff(RatNum(-1))

    def __add__(self, other: "RatPoly") -> "RatPoly":
        
        if self._is_nan or other._is_nan:
            return RatPoly.NAN
        new_terms = dict(self._terms)
        for expt, coeff in other._terms.items():
            summed = new_terms.get(expt, RatNum.ZERO) + coeff
            if summed == RatNum.ZERO:
                new_terms.pop(expt, None)
            else:
                new_terms[expt] = summed
        return RatPoly._from_terms(new_terms)

    def __sub__(self, other: "RatPoly") -> "RatPoly":
       
        return self + (-other)

    def __mul__(self, other: "RatPoly") -> "RatPoly":
       
        if self._is_nan or other._is_nan:
            return RatPoly.NAN
        new_terms: Dict[int, RatNum] = {}
        for e1, c1 in self._terms.items():
            for e2, c2 in other._terms.items():
                e = e1 + e2
                new_terms[e] = new_terms.get(e, RatNum.ZERO) + c1 * c2
        new_terms = {e: c for e, c in new_terms.items() if c != RatNum.ZERO}
        return RatPoly._from_terms(new_terms)

    def __truediv__(self, other: "RatPoly") -> "RatPoly":
        
        if self._is_nan or other._is_nan or not other._terms:
            return RatPoly.NAN

        remainder = dict(self._terms)
        divisor_deg = other.degree()
        divisor_lead = other._terms[divisor_deg]
        quotient: Dict[int, RatNum] = {}

        while remainder:
            rem_deg = max(remainder.keys())
            if rem_deg < divisor_deg:
                break
            factor = remainder[rem_deg] / divisor_lead
            q_expt = rem_deg - divisor_deg
            quotient[q_expt] = quotient.get(q_expt, RatNum.ZERO) + factor
            for e2, c2 in other._terms.items():
                e = q_expt + e2
                new_val = remainder.get(e, RatNum.ZERO) - factor * c2
                if new_val == RatNum.ZERO:
                    remainder.pop(e, None)
                else:
                    remainder[e] = new_val

        quotient = {e: c for e, c in quotient.items() if c != RatNum.ZERO}
        return RatPoly._from_terms(quotient)

 

    def differentiate(self) -> "RatPoly":
        
        if self._is_nan:
            return RatPoly.NAN
        new_terms: Dict[int, RatNum] = {}
        for expt, coeff in self._terms.items():
            if expt == 0:
                continue
            new_coeff = coeff * RatNum(expt)
            if new_coeff != RatNum.ZERO:
                new_terms[expt - 1] = new_coeff
        return RatPoly._from_terms(new_terms)

    def anti_differentiate(self, integration_constant: RatNum) -> "RatPoly":
        
        if self._is_nan or integration_constant.is_nan():
            return RatPoly.NAN
        new_terms: Dict[int, RatNum] = {}
        for expt, coeff in self._terms.items():
            new_terms[expt + 1] = coeff / RatNum(expt + 1)
        if integration_constant != RatNum.ZERO:
            new_terms[0] = integration_constant
        return RatPoly._from_terms(new_terms)

    def integrate(self, lower_bound: RatNum, upper_bound: RatNum) -> RatNum:
        
        if self._is_nan or lower_bound.is_nan() or upper_bound.is_nan():
            return RatNum.NAN
        antiderivative = self.anti_differentiate(RatNum.ZERO)
        return antiderivative.eval(upper_bound) - antiderivative.eval(lower_bound)

    

    def eval(self, x: RatNum) -> RatNum:
        
        if self._is_nan or x.is_nan():
            return RatNum.NAN
        if not self._terms:
            return RatNum.ZERO
        degree = max(self._terms.keys())
        result = RatNum.ZERO
        for expt in range(degree, -1, -1):
            result = result * x + self._terms.get(expt, RatNum.ZERO)
        return result

    def value_of(self, x: float) -> float:
        
        if self._is_nan:
            return float("nan")
        if not self._terms:
            return 0.0
        degree = max(self._terms.keys())
        result = 0.0
        for expt in range(degree, -1, -1):
            result = result * x + self._terms.get(expt, RatNum.ZERO).float_value()
        return result

    

    def __str__(self) -> str:
        
        if self._is_nan:
            return "NaN"
        if not self._terms:
            return "0"

        parts = []
        for expt in sorted(self._terms.keys(), reverse=True):
            coeff = self._terms[expt]
            neg = coeff.is_negative()
            mag = -coeff if neg else coeff

            if expt == 0:
                term = str(mag)
            elif mag == RatNum.ONE:
                term = "x" if expt == 1 else f"x^{expt}"
            else:
                term = f"{mag}*x" if expt == 1 else f"{mag}*x^{expt}"

            if not parts:
                parts.append(("-" if neg else "") + term)
            else:
                parts.append((" - " if neg else " + ") + term)
        return "".join(parts)

    def __repr__(self) -> str:
        return f"RatPoly.from_coefficients(...) representing '{self}'"

    def __hash__(self) -> int:
        
        if self._is_nan:
            return hash("RatPoly.NaN")
        return hash(frozenset(self._terms.items()))

    def __eq__(self, other: object) -> bool:
        
        if not isinstance(other, RatPoly):
            return NotImplemented
        if self._is_nan or other._is_nan:
            return self._is_nan and other._is_nan
        return self._terms == other._terms

RatPoly.NAN = RatPoly(RatNum.NAN, 0)
