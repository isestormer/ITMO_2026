from __future__ import annotations
from math import gcd as _gcd


class RatNum:
    __slots__ = ("_numer", "_denom")

    def __init__(self, numerator: int = 0, denominator: int = 1):
        if not isinstance(numerator, int) or not isinstance(denominator, int):
            raise TypeError("numerator and denominator must be int")

        if denominator == 0:
            object.__setattr__(self, "_numer", 0)
            object.__setattr__(self, "_denom", 0)
        elif numerator == 0:
            object.__setattr__(self, "_numer", 0)
            object.__setattr__(self, "_denom", 1)
        else:
            g = _gcd(abs(numerator), abs(denominator))
            sign = -1 if (numerator < 0) != (denominator < 0) else 1
            object.__setattr__(self, "_numer", sign * (abs(numerator) // g))
            object.__setattr__(self, "_denom", abs(denominator) // g)

        self._check_rep()

    def __setattr__(self, name, value):
        raise AttributeError("RatNum is immutable")

    def _check_rep(self) -> None:
        assert isinstance(self._numer, int) and isinstance(self._denom, int)
        assert self._denom >= 0
        if self._denom == 0:
            assert self._numer == 0
        else:
            if self._numer == 0:
                assert self._denom == 1
            else:
                assert _gcd(abs(self._numer), self._denom) == 1

    def is_nan(self) -> bool:
       
        return self._denom == 0

    def is_negative(self) -> bool:
        
        return (not self.is_nan()) and self._numer < 0

    def is_positive(self) -> bool:
        
        return (not self.is_nan()) and self._numer > 0

    def compare_to(self, other: "RatNum") -> int:
        
        if self.is_nan() and other.is_nan():
            return 0
        if self.is_nan():
            return 1
        if other.is_nan():
            return -1
        lhs = self._numer * other._denom
        rhs = other._numer * self._denom
        return (lhs > rhs) - (lhs < rhs)

    def float_value(self) -> float:
        
        if self.is_nan():
            return float("nan")
        return self._numer / self._denom

    def int_value(self) -> int:
        
        if self.is_nan():
            raise ValueError("cannot take int_value() of NaN")
        sign = -1 if self._numer < 0 else 1
        return sign * (abs(self._numer) // self._denom)

    def gcd(self, other: "RatNum") -> "RatNum":
        if self.is_nan() or other.is_nan():
            raise ValueError("gcd is undefined for NaN")
        if self._denom != 1 or other._denom != 1:
            raise ValueError("gcd requires integer-valued RatNums")
        return RatNum(_gcd(abs(self._numer), abs(other._numer)))


    def __neg__(self) -> "RatNum":
        
        if self.is_nan():
            return RatNum.NAN
        return RatNum(-self._numer, self._denom)

    def __add__(self, other: "RatNum") -> "RatNum":
        
        if self.is_nan() or other.is_nan():
            return RatNum.NAN
        numer = self._numer * other._denom + other._numer * self._denom
        denom = self._denom * other._denom
        return RatNum(numer, denom)

    def __sub__(self, other: "RatNum") -> "RatNum":
        
        return self + (-other)

    def __mul__(self, other: "RatNum") -> "RatNum":
        
        if self.is_nan() or other.is_nan():
            return RatNum.NAN
        return RatNum(self._numer * other._numer, self._denom * other._denom)

    def __truediv__(self, other: "RatNum") -> "RatNum":
        
        if self.is_nan() or other.is_nan() or other._numer == 0:
            return RatNum.NAN
        return RatNum(self._numer * other._denom, self._denom * other._numer)

    def __str__(self) -> str:
        
        if self.is_nan():
            return "NaN"
        if self._denom == 1:
            return str(self._numer)
        return f"{self._numer}/{self._denom}"

    def __repr__(self) -> str:
        return f"RatNum({self._numer!r}, {self._denom!r})"

    def __hash__(self) -> int:
        
        return hash((self._numer, self._denom))

    def __eq__(self, other: object) -> bool:
        
        if not isinstance(other, RatNum):
            return NotImplemented
        return self._numer == other._numer and self._denom == other._denom

    
    def __lt__(self, other: "RatNum") -> bool:
        return self.compare_to(other) < 0

    def __le__(self, other: "RatNum") -> bool:
        return self.compare_to(other) <= 0

    def __gt__(self, other: "RatNum") -> bool:
        return self.compare_to(other) > 0

    def __ge__(self, other: "RatNum") -> bool:
        return self.compare_to(other) >= 0


RatNum.ZERO = RatNum(0)
RatNum.ONE = RatNum(1)
RatNum.NAN = RatNum(0, 0)
