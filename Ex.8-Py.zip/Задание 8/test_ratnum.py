import unittest
from ratnum import RatNum


class TestConstruction(unittest.TestCase):
    def test_reduces_to_lowest_terms(self):
        self.assertEqual(RatNum(2, 4), RatNum(1, 2))
        self.assertEqual(RatNum(-6, 3), RatNum(-2, 1))

    def test_normalizes_sign_to_numerator(self):
        r = RatNum(1, -2)
        self.assertEqual(str(r), "-1/2")
        r2 = RatNum(-1, -2)
        self.assertEqual(str(r2), "1/2")

    def test_zero_canonical_form(self):
        self.assertEqual(str(RatNum(0, 5)), "0")
        self.assertEqual(str(RatNum(0, -5)), "0")

    def test_denominator_zero_is_nan(self):
        self.assertTrue(RatNum(5, 0).is_nan())
        self.assertTrue(RatNum(0, 0).is_nan())
        self.assertTrue(RatNum(-3, 0).is_nan())

    def test_examples_from_spec(self):
        self.assertEqual(str(RatNum(-1, 13)), "-1/13")
        self.assertEqual(str(RatNum(53, 7)), "53/7")
        self.assertEqual(str(RatNum(4, 1)), "4")
        self.assertEqual(str(RatNum(0, 0)), "NaN")
        self.assertEqual(str(RatNum(0, 1)), "0")

    def test_rejects_non_int(self):
        with self.assertRaises(TypeError):
            RatNum(1.5, 2)


class TestIsNan(unittest.TestCase):
    def test_ordinary_not_nan(self):
        self.assertFalse(RatNum(1, 2).is_nan())

    def test_nan_is_nan(self):
        self.assertTrue(RatNum.NAN.is_nan())


class TestIsNegativeIsPositive(unittest.TestCase):
    def test_negative(self):
        self.assertTrue(RatNum(-1, 2).is_negative())
        self.assertFalse(RatNum(1, 2).is_negative())
        self.assertFalse(RatNum(0).is_negative())

    def test_positive(self):
        self.assertTrue(RatNum(1, 2).is_positive())
        self.assertFalse(RatNum(-1, 2).is_positive())
        self.assertFalse(RatNum(0).is_positive())

    def test_nan_is_neither(self):
        self.assertFalse(RatNum.NAN.is_negative())
        self.assertFalse(RatNum.NAN.is_positive())


class TestCompareTo(unittest.TestCase):
    def test_ordinary_ordering(self):
        self.assertLess(RatNum(1, 2).compare_to(RatNum(2, 3)), 0)
        self.assertGreater(RatNum(2, 3).compare_to(RatNum(1, 2)), 0)
        self.assertEqual(RatNum(1, 2).compare_to(RatNum(2, 4)), 0)

    def test_negative_vs_positive(self):
        self.assertLess(RatNum(-1, 2).compare_to(RatNum(1, 3)), 0)

    def test_nan_equals_itself(self):
        self.assertEqual(RatNum.NAN.compare_to(RatNum.NAN), 0)

    def test_nan_greater_than_everything(self):
        self.assertGreater(RatNum.NAN.compare_to(RatNum(10 ** 9)), 0)
        self.assertLess(RatNum(10 ** 9).compare_to(RatNum.NAN), 0)
        self.assertGreater(RatNum.NAN.compare_to(RatNum(-(10 ** 9))), 0)

    def test_rich_comparisons(self):
        self.assertTrue(RatNum(1, 3) < RatNum(1, 2))
        self.assertTrue(RatNum(1, 2) >= RatNum(1, 2))


class TestFloatValue(unittest.TestCase):
    def test_ordinary(self):
        self.assertAlmostEqual(RatNum(1, 4).float_value(), 0.25)
        self.assertAlmostEqual(RatNum(-3, 2).float_value(), -1.5)

    def test_nan(self):
        import math
        self.assertTrue(math.isnan(RatNum.NAN.float_value()))


class TestIntValue(unittest.TestCase):
    def test_exact(self):
        self.assertEqual(RatNum(6, 3).int_value(), 2)

    def test_truncates_toward_zero_positive(self):
        self.assertEqual(RatNum(7, 2).int_value(), 3)

    def test_truncates_toward_zero_negative(self):
        self.assertEqual(RatNum(-7, 2).int_value(), -3)

    def test_nan_throws(self):
        with self.assertRaises(ValueError):
            RatNum.NAN.int_value()


class TestGcd(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(RatNum(12).gcd(RatNum(18)), RatNum(6))
        self.assertEqual(RatNum(-12).gcd(RatNum(18)), RatNum(6))

    def test_zero(self):
        self.assertEqual(RatNum(0).gcd(RatNum(0)), RatNum(0))
        self.assertEqual(RatNum(0).gcd(RatNum(5)), RatNum(5))

    def test_nan_throws(self):
        with self.assertRaises(ValueError):
            RatNum.NAN.gcd(RatNum(1))

    def test_non_integer_throws(self):
        with self.assertRaises(ValueError):
            RatNum(1, 2).gcd(RatNum(1))


class TestArithmetic(unittest.TestCase):
    def test_neg(self):
        self.assertEqual(-RatNum(3, 4), RatNum(-3, 4))
        self.assertEqual(-RatNum(0), RatNum(0))
        self.assertTrue((-RatNum.NAN).is_nan())

    def test_add(self):
        self.assertEqual(RatNum(1, 2) + RatNum(1, 3), RatNum(5, 6))
        self.assertEqual(RatNum(1, 2) + RatNum(-1, 2), RatNum(0))

    def test_sub(self):
        self.assertEqual(RatNum(1, 2) - RatNum(1, 3), RatNum(1, 6))

    def test_mul(self):
        self.assertEqual(RatNum(2, 3) * RatNum(3, 4), RatNum(1, 2))
        self.assertEqual(RatNum(0) * RatNum(5, 7), RatNum(0))

    def test_div(self):
        self.assertEqual(RatNum(1, 2) / RatNum(1, 4), RatNum(2))

    def test_div_by_zero_is_nan(self):
        self.assertTrue((RatNum(1, 2) / RatNum(0)).is_nan())

    def test_nan_propagates(self):
        self.assertTrue((RatNum.NAN + RatNum(1)).is_nan())
        self.assertTrue((RatNum(1) + RatNum.NAN).is_nan())
        self.assertTrue((RatNum.NAN - RatNum(1)).is_nan())
        self.assertTrue((RatNum.NAN * RatNum(1)).is_nan())
        self.assertTrue((RatNum.NAN / RatNum(1)).is_nan())
        self.assertTrue((RatNum(1) / RatNum.NAN).is_nan())


class TestStrHashEq(unittest.TestCase):
    def test_str_forms(self):
        self.assertEqual(str(RatNum(-1, 13)), "-1/13")
        self.assertEqual(str(RatNum(4)), "4")
        self.assertEqual(str(RatNum.NAN), "NaN")

    def test_eq_reflexive_and_value_based(self):
        self.assertEqual(RatNum(1, 2), RatNum(2, 4))
        self.assertNotEqual(RatNum(1, 2), RatNum(1, 3))

    def test_nan_equals_nan(self):
        self.assertEqual(RatNum.NAN, RatNum(0, 0))
        self.assertEqual(RatNum.NAN, RatNum(5, 0))

    def test_hash_consistent_with_eq(self):
        self.assertEqual(hash(RatNum(1, 2)), hash(RatNum(2, 4)))
        self.assertEqual(hash(RatNum.NAN), hash(RatNum(7, 0)))

    def test_usable_in_sets(self):
        s = {RatNum(1, 2), RatNum(2, 4), RatNum(1, 3)}
        self.assertEqual(len(s), 2)


class TestImmutability(unittest.TestCase):
    def test_cannot_mutate(self):
        r = RatNum(1, 2)
        with self.assertRaises(AttributeError):
            r._numer = 99


if __name__ == "__main__":
    unittest.main()
